using Microsoft.AspNetCore.Mvc;
using lilianApi.Models;
using lilianApi.Services;
using System.Collections.Generic;

namespace lilianApi.Controllers
{
    [Route("api/users")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly UserService _userService;

        public UserController()
        {
            _userService = new UserService();
        }

        [HttpGet]
        public ActionResult<List<User>> GetUsers()
        {
            var users = _userService.GetUsers();
            return Ok(users);
        }
    }
}
