using lilianApi.Models;
using System.Collections.Generic;

namespace lilianApi.Services
{
    public class UserService
    {
        public List<User> GetUsers()
        {
            return new List<User>
            {
                new User { Id = 1, Name = "Karla", Email = "karla@gmail.com" },
                new User { Id = 2, Name = "Lilian", Email = "lilian@gmail.com" },
                new User { Id = 3, Name = "Garcia", Email = "garcia@gmail.com" },
                new User { Id = 3, Name = "Ramirez", Email = "ramirez@gmail.com" }

            };
        }
    }
}